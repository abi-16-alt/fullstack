import React, { useState } from 'react'

const About = () => {
    const[color,setColor]=useState("Red");
    const[car,setCar]=useState({
        model:"swift",
        year:1991,
    });
  return (
    <div>
        <h1>{color}</h1>
        <button onClick={()=>setColor("Blue")}>click</button>
        <h1>{car.model}</h1>
        <h1>{car.year}</h1>
        <button onClick={()=>setCar(prev=>{
            return{
                ...prev,year:2000,model:"volvo"}
            })
        }>change</button>
    </div>
    
  )
}

export default About