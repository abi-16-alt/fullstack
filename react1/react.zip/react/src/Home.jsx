import React from 'react'
import Header from './Header';
import Footer from './Footer';

const Home = (props) => {
    const shoot=()=>{
        alert("Great Shot!");

    }
  return (
    <div>
        <Header/>
        <Footer/>
        {props.name}
        <button onclick={shoot}>click</button>
    </div>
  )
}

export default Home