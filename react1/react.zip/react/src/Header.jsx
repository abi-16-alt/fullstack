import React, { useState } from 'react'

const Header = () => {
    //let count=0;
    const[count,setCount]=useState(0);
    function increase() {
        setCount(count+1);
        //count++;
        //console.log(count);
        
    }
  return (
    <div>
        <h1>count-{count}</h1>
        <button onClick={increase}>UP</button>
    </div>
  )
}

export default Header