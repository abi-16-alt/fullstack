import React from 'react'
import Home from './Home'
import About from './About'

function App(){
  return(
    <>
    <Home/>
    <About/>
    </>
  )
  
}

export default App