import React from 'react'
import './Middle.css';

function Middle() {
  return (
    <div>
    <div id='Div2'>
        <div id='main2'>
            <div id='main21'>
                <img src='hoodie.jpg'></img>

            </div>
            <div id='main22'>
                <h1>Hoodie</h1>
                <h1>Price:$25</h1>
                <p>Make you comfort</p>
                <button>Select</button>

            </div>
        </div>
        <div id='main3'>
            <h1>Order Today</h1>
            <h1>Unwrap Tommorrow</h1>
        </div>
    </div>
    </div>
  )
}

export default Middle