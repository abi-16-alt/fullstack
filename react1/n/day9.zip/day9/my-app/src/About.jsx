import React from 'react'

function About() {
  return (
    <div>
        <h1>Welcome to about</h1>
    </div>
  )
}

export default About