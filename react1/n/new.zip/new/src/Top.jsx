import React from 'react';
import './Top.css';

function Top() {
  return (
    <div id="Top">
      <h1 id="Top_h1">Shop Now</h1>
    </div>
  );
}

export default Top;
