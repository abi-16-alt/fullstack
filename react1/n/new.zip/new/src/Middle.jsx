import React from 'react';
import './Middle.css';
function Middle() {
  return (
    <div id="Middle">
      <h1>Order Now</h1>
      <h1>Welcome</h1>
    </div>
  );
}

export default Middle;
