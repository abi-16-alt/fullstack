import React from 'react';
import './Bottom.css';

function Bottom() {
  return (
    <div id="Bottom">
      <h1>@ourshop.in</h1>
    </div>
  );
}

export default Bottom;
