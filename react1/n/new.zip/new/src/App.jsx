import React from 'react';
import Top from './Top';
import Bottom from './Bottom';
import Middle from './Middle';

const App = () => {
  return (
    <>
      <Top />
      <Middle />
      <Bottom />
    </>
  );
};

export default App;
